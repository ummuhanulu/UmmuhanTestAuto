package protelTestAuto.io.protelTestAuto;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Paths {

    public Paths(WebDriver driver) {
	}
	public static final By signIn =  By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a");
	public static final By emailCreate = By.id("email_create");
	public static final By createAccount = By.xpath("//*[@id=\"SubmitCreate\"]");
	
	public static final By Mrs =  By.id("uniform-id_gender2");
	public static final By firstname =  By.id("customer_firstname");
	public static final By lastname =  By.id("customer_lastname");
	public static final By email =  By.id("email");
	public static final By password =  By.id("passwd");
	public static final By day =  By.id("days");
	public static final By month =  By.id("months");
	public static final By year =  By.id("years");
	public static final By newsletter =  By.id("uniform-newsletter");
	public static final By option =  By.id("uniform-optin");
	public static final By address =  By.id("address1");
	public static final By city =  By.id("city");
	public static final By state =  By.id("id_state");
	public static final By postcode =  By.id("postcode");
	public static final By country =  By.id("id_country");
	public static final By information =  By.id("other");
	public static final By phone =  By.name("phone_mobile");
	public static final By addressType =  By.id("alias");
	public static final By cart =  By.xpath("//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a");
	public static final By tshirt =  By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/ul/li[1]/ul/li[1]/a");
	public static final By addToCart = By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/div[2]/a[1]");
	public static final By proceed = By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span");
	public static final By proceed2 = By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]/span");
	public static final By proceed3 = By.xpath("//*[@id=\"center_column\"]/form/p/button/span");
	public static final By check = By.id("uniform-cgv");
	public static final By payment = By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[1]/div/p/a/span");
	public static final By confirm =  By.xpath("//*[@id=\"cart_navigation\"]/button/span");

}
