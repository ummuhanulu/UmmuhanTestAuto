package protelTestAuto.io.protelTestAuto;
public class ChromeDriver {
	
	  public static void prepareToConnectChrome()
	    {
	        System.setProperty("webdriver.chrome.driver", "/io.protelTestAuto/src/test/java/chromeDriver/chromedriver.exe");
	    }
}
