package protelTestAuto.io.protelTestAuto;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

public class RunClass extends ChromeDriver {
  
	private static WebDriver driver;

    @BeforeClass
    public static void setUp() throws Exception {

    	prepareToConnectChrome();
    }

    @AfterClass
    public static void tearDown() throws Exception {
        driver.quit();
    }
    @Test
    public  void testAuto() throws InterruptedException {

        new LoginAction(driver).login();

}

}
