package protelTestAuto.io.protelTestAuto;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class LoginAction extends Paths {

	public LoginAction(WebDriver driver) {
		super(driver);
	}

	public void selectElement(By locator) {
		Select selectElement = new Select(driver.findElement(locator));
		selectElement.selectByIndex(3);
	}

	WebDriver driver;

	public void login() {

		driver.get("http://automationpractice.com/");
		driver.findElement(signIn).click();
		driver.findElement(emailCreate).sendKeys("autotesttets@test.com");
		driver.findElement(createAccount).click();
		driver.findElement(Mrs).click();
		driver.findElement(firstname).sendKeys("Test");
		driver.findElement(lastname).sendKeys("Test");
		Object object = driver.findElement(email).getText();
		Assert.assertEquals(object, "autotesttets@test.com");
		driver.findElement(password).sendKeys("testttt");
		selectElement(day);
		selectElement(month);
		selectElement(year);
		driver.findElement(newsletter).click();
		driver.findElement(option).click();
		driver.findElement(address).sendKeys("address1");
		driver.findElement(city).sendKeys("city");
		selectElement(city);
		selectElement(state);
		driver.findElement(postcode).sendKeys("postcode");
		selectElement(country);
		driver.findElement(information).sendKeys("information");
		driver.findElement(phone).sendKeys("phone");
		driver.findElement(addressType).sendKeys("alias");
		driver.findElement(cart).click();
		driver.findElement(tshirt).click();
		driver.findElement(addToCart).click();
		driver.findElement(proceed).click();
		driver.findElement(proceed2).click();
		driver.findElement(proceed3).click();
		driver.findElement(check).click();
		driver.findElement(payment).click();
		driver.findElement(confirm).click();

	}
}
